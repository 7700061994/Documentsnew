﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ANTLRProject;
using ANTLRProject.Model;
namespace Demo
{
    public static class Program
    {
        static void Main(string[] args)
        {
            string cqlFilePath = "C:\\Users\\Ashu\\Downloads\\AISE\\AISE\\cql\\AISE_HEDIS_MY2022-1.0.0.cql";

            string cqlQuery = File.ReadAllText(cqlFilePath);
            var fs = new FileStream(cqlFilePath, FileMode.Open, FileAccess.Read);
            CqlToElmConverter cqlToElm = new CqlToElmConverter();
            string elmQuery = cqlToElm.ConvertCqlToElm(fs);
            Console.WriteLine(elmQuery);
        }
    }
}
