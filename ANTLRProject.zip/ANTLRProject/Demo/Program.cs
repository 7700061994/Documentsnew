﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ANTLRProject;
using ANTLRProject.Model;
namespace Demo
{
    public static class Program
    {
        static void Main(string[] args)
        {
            //Converting CQL into string
            // string cqlQuery = File.ReadAllText(cqlFilePath);
            
            // Cql filepth

            string cqlFilePath = "C:\\antlr\\AISE_HEDIS_MY2022-1.0.0.cql";

            // converting cql into input stream
            var fs = new FileStream(cqlFilePath, FileMode.Open, FileAccess.Read);
            CqlToElmConverter cqlToElm = new CqlToElmConverter();

            
            string elmQuery = cqlToElm.ConvertCqlToElm(fs);
            Console.WriteLine(elmQuery);
        }
    }
}
