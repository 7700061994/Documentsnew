﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ANTLRProject;
using ANTLRProject.Model;
namespace Demo
{
    public static class Program
    {
        static void Main(string[] args)
        {
            string cqlFilePath = "C:\\antlr\\AISE_HEDIS_MY2022-1.0.0.cql";

            string cqlQuery = File.ReadAllText(cqlFilePath);
            CqlToElmConverter cqlToElm = new CqlToElmConverter();
            string elmQuery = cqlToElm.ConvertCqlToElm(cqlQuery);
            Console.WriteLine(elmQuery);
        }
    }
}
