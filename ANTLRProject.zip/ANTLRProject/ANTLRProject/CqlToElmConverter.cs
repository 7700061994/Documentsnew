﻿using Antlr4.Runtime;
using Antlr4.Runtime.Tree;
using ANTLRProject.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject
{
    public class CqlToElmConverter
    {
        public string ConvertCqlToElm(string source)
        {
            var inputStream = new AntlrInputStream(source);
            var lexer = new cqlLexer(inputStream);
            var tokenStream = new CommonTokenStream(lexer);
            var parser = new cqlParser(tokenStream);
            var parseTree = parser.library();
            var visitor = new cqlTranslationVisitor();
            var result= visitor.Visit(parseTree) ;
            return JsonConvert.SerializeObject(result);
        }
       
    }
}
