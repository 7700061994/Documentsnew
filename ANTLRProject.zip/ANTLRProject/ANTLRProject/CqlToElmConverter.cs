﻿using Antlr4.Runtime;
using Antlr4.Runtime.Tree;
using ANTLRProject.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace ANTLRProject
{
    public class CqlToElmConverter
    {
        public string ConvertCqlToElm(FileStream source)
        {
            // input cql 
            var inputStream = new AntlrInputStream(source);
            // generating lexer
            var lexer = new cqlLexer(inputStream);
            //converting lexer into token
            var tokenStream = new CommonTokenStream(lexer);

            // Token to parser
            var parser = new cqlParser(tokenStream);
            // generating the tree
            var parseTree = parser.library();
            // By using Visitor , which walk the tree along the nodes
            var visitor = new cqlTranslationVisitor();
            var result= visitor.VisitLibrary(parseTree) ;
            XDocument xDocument = new XDocument(new XElement("library",result));
            string xmlString = xDocument.ToString();

            XDocument doc = XDocument.Parse(xmlString);


         //var defTree = parser.usingDefinition();
         // var def = visitor.VisitUsingDefinition(defTree);
            return JsonConvert.SerializeXNode(doc);
        }
       
    }
}
