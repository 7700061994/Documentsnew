﻿using Antlr4.Runtime;
using Antlr4.Runtime.Tree;
using ANTLRProject.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ANTLRProject
{
    public class CqlToElmConverter
    {
        public string ConvertCqlToElm(FileStream source)
        {
            // input cql 
            var inputStream = new AntlrInputStream(source);
            // generating lexer
            var lexer = new cqlLexer(inputStream);
            //converting lexer into token
            var tokenStream = new CommonTokenStream(lexer);

            // Token to parser
            var parser = new cqlParser(tokenStream);
            // generating the tree
            var parseTree = parser.library();
            // By using Visitor , which walk the tree along the nodes
            var visitor = new cqlTranslationVisitor();
            var result= visitor.VisitLibrary(parseTree) ;

           var JsonOutPut = JsonConvert.SerializeObject(result);
            Console.WriteLine(JsonOutPut.ToString());// Print XML output
            string xmlOutput = "";
            //using (StringWriter writer = new StringWriter())
            //{
            //    XmlSerializer serializer = new XmlSerializer(typeof(Library));
            //    serializer.Serialize(writer, result);
                
            //    xmlOutput = writer.ToString();
            //    Console.WriteLine(xmlOutput); // Print XML output
            //}
            //XDocument doc = XDocument.Parse(xmlOutput);
            //string libraryJsonString = JsonConvert.SerializeXNode(doc);
            //Console.WriteLine(libraryJsonString);
            // Write the XML to the console
            return xmlOutput.ToString();
        }
       
    }
}
