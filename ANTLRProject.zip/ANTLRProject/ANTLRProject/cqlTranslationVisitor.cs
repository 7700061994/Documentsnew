﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Antlr4.Runtime.Misc;
using Antlr4.Runtime.Tree;
using ANTLRProject.Model;



namespace ANTLRProject
{
    public class cqlTranslationVisitor : cqlBaseVisitor<Element>
    {
        #region ParseTreeVisitorMethods

        public override Element Visit(IParseTree tree)
        {
            return base.Visit(tree);
        }

        public override Element VisitChildren(IRuleNode node)
        {
            return base.VisitChildren(node);
        }

        protected override bool ShouldVisitNextChild(IRuleNode node, Element currentResult)
        {
            return base.ShouldVisitNextChild(node, currentResult);
        }

        protected Element DefaultResult()
        {
            return new Null();
        }

        protected override Element AggregateResult(Element aggregate, Element nextResult)
        {
            return base.AggregateResult(aggregate, nextResult);
        }

        public override Element VisitErrorNode(IErrorNode node)
        {
            return base.VisitErrorNode(node);
        }

        public override Element VisitTerminal(ITerminalNode node)
        {
            return base.VisitTerminal(node);
        }

        #endregion

        #region CQLHelperMethods

        private string GetClassName(string existenceModifier, string topic, string modality)
        {
            return String.Format("{0}{1}{2}", topic, modality ?? String.Empty, existenceModifier);
        }

        #endregion

        #region CQLGrammarMethods

        public override Element VisitLibrary(cqlParser.LibraryContext context)
        {
            return base.VisitLibrary(context);
        }
        public override Element VisitRetrieve(cqlParser.RetrieveContext context)
        {
            //var occurrence = context.occurrence();
            //var topic = context.topic();
            //var modality = context.modality();
            //var className =
            //    GetClassName
            //    (
            //        occurrence == null
            //            ? "Occurrence"
            //            : (occurrence.GetText() == "no" ? "NonOccurrence" : "UnknownOccurrence"),
            //        topic.GetText(),
            //        modality == null ? null : modality.GetText()
            //    );

            //var valueset = context.valueset();
            //var valuesetPathIdentifier = context.valuesetPathIdentifier();
            //var during = context.expression();
            //var duringPathIdentifier = context.duringPathIdentifier();

            var request = new ClinicalRequest();

            request.cardinality = RequestCardinality.Multiple;
            //request.dataType = className; // TODO: xml qualifier for data model?
            //if (valueset != null)
            //{
            //    request.codes = (Expression)Visit(valueset);
            //    if (valuesetPathIdentifier != null)
            //    {
            //        request.codeProperty = valuesetPathIdentifier.GetText();
            //    }
            //}

            //if (during != null)
            //{
            //    request.dateRange = (Expression)Visit(during);
            //    if (duringPathIdentifier != null)
            //    {
            //        request.dateProperty = duringPathIdentifier.GetText();
            //    }
            //}

            return request;
        }

        public override Element VisitQualifiedIdentifier(cqlParser.QualifiedIdentifierContext context)
        {
            var qualifier = context.qualifier();
            var identifier = context.identifier().GetText();

            return new ExpressionRef { libraryName = qualifier == null ? null : qualifier.ToString(), name = identifier };
        }

        public override Element VisitQuerySource(cqlParser.QuerySourceContext context)
        {
            var retrieve = context.retrieve();
            if (retrieve != null)
            {
                return VisitRetrieve(retrieve);
            }

            var qualifiedIdentifier = context.qualifiedIdentifier();
            if (qualifiedIdentifier != null)
            {
                return VisitQualifiedIdentifier(qualifiedIdentifier);
            }

            var expression = context.expression();
            if (expression != null)
            {
                return Visit(expression);
            }

            throw new NotSupportedException("Unknown query source category.");
        }

        public override Element VisitQuery(cqlParser.QueryContext context)
        {
            var aliasedSource = context.sourceClause();
           var querySource = (Expression)Visit(aliasedSource.aliasedQuerySource(0).querySource());
            var alias = aliasedSource.aliasedQuerySource(0).alias().GetText();
           var result = (Expression)new Filter { source = querySource, scope = alias };
            var condition = new And { operand = new List<Expression>() };

            foreach (var queryInclusionClause in context.queryInclusionClause())
            {
                // NOTE: This only works with "with" clauses right now. If we add "combine" it will need to be dealt with here.
                var withSource = (Expression)VisitQuerySource(queryInclusionClause.aliasedQuerySource().querySource());
                var withAlias = queryInclusionClause.aliasedQuerySource().alias().GetText();
                var withCondition = (Expression)Visit(queryInclusionClause.expression());
                var withExpression = new IsNotEmpty { operand = new Filter { source = withSource, scope = withAlias, condition = withCondition } };
                condition.operand.Add(withExpression);
            }

            var whereClause = context.whereClause();
            if (whereClause != null)
            {
                condition.operand.Add((Expression)Visit(whereClause.expression()));
            }

            var returnClause = context.returnClause();
            if (returnClause != null)
            {
                result = new ForEach { source = result, scope = alias, element = (Expression)Visit(returnClause.expression()) };
            }

            var sortClause = context.sortClause();
            if (sortClause != null)
            {
                var sortDirection = sortClause.sortDirection();
                if (sortDirection != null)
                {
                    if (sortDirection.GetText() != "asc")
                    {
                        // TODO: CQL-LM must be modified to support directional sort
                        throw new NotSupportedException();
                    }

                    result = new Sort { source = result };
                }
                else
                {
                    if (sortClause.sortByItem().Count() != 1)
                    {
                        // TODO: CQL-LM must be modified to support multi-column sort
                        throw new NotSupportedException();
                    }

                    if (sortClause.sortByItem(0).sortDirection() != null && sortClause.sortByItem(0).sortDirection().GetText() != "asc")
                    {
                        // TODO: CQL-LM must be modified to support directional sort
                        throw new NotSupportedException();
                    }

                    return new Sort { source = result, orderBy = sortClause.sortByItem(0).expressionTerm().GetText() };
                }
            }

            return result;
        }

        public override Element VisitAdditionExpressionTerm(cqlParser.AdditionExpressionTermContext context)
        {
            return new Add { operand = new List<Expression> { (Expression)Visit(context.expressionTerm(0)), (Expression)Visit(context.expressionTerm(1)) } };
        }

        public override Element VisitAggregateExpressionTerm(cqlParser.AggregateExpressionTermContext context)
        {
            switch (context.GetChild(0).GetText())
            {
                case "distinct":
                    return new Distinct { source = (Expression)Visit(context.expression()) };
                    break;

                case "collapse":
                    return new Collapse { operand = (Expression)Visit(context.expression()) };
                    break;

                case "expand":
                    return new Expand { operand = (Expression)Visit(context.expression()) };
                    break;
            }

            throw new NotSupportedException(String.Format("Unrecognized operator for aggregateExpressionTerm: {0}", context.GetChild(0).GetText()));
        }

        public override Element VisitDefinition(cqlParser.DefinitionContext context)
        {
            var library = new Library();

            foreach (var usingDefinition in context.usingDefinition())
            {
                //throw new NotImplementedException();
            }

          

            foreach (var parameterDefinition in context.parameterDefinition())
            {
                library.parameters.Add(new ParameterDef { name = parameterDefinition.identifier().GetText(), parameterType = new XmlQualifiedName(parameterDefinition.typeSpecifier().GetText()) });
            }


            string currentContext = Contexts.PATIENT;
            foreach (var statement in context.statement())
            {
                var contextDefinition = statement.contextDefinition();
                if (contextDefinition != null)
                {
                    var newContext = contextDefinition.identifier().GetText();
                    if (newContext == Contexts.PATIENT || newContext == Contexts.POPULATION)
                    {
                        currentContext = newContext;
                    }
                    else
                    {
                        throw new InvalidOperationException(String.Format("Unknown context {0}.", newContext));
                    }
                }

                var letStatement = statement.expressionDefinition();
                if (letStatement != null)
                {
                    library.statements.Add(new ExpressionDef { name = letStatement.identifier().GetText(), context = currentContext, expression = (Expression)Visit(letStatement.expression()) });
                }

                var functionDefinition = statement.functionDefinition();
                if (functionDefinition != null)
                {
                    var functionDef = new FunctionDef { name = functionDefinition.identifierOrFunctionIdentifier().GetText(), context = currentContext, expression = (Expression)Visit(functionDefinition.functionBody()) };
                    foreach (var parameter in functionDefinition.operandDefinition())
                    {
                        // TODO: More complete type resolution here, although ELM will have to be expanded to support this as well....
                        functionDef.parameter.Add(new ParameterDef { name = parameter.referentialIdentifier().GetText(), parameterType = new XmlQualifiedName(parameter.typeSpecifier().GetText()) });
                    }

                    library.statements.Add(functionDef);
                }

               
            }

            return library;
        }

        #endregion
    }
}
