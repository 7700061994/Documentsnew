﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Antlr4.Runtime.Misc;
using Antlr4.Runtime.Tree;
using ANTLRProject.Model;



namespace ANTLRProject
{
    public class cqlTranslationVisitor : cqlBaseVisitor<Element>
    {

        private readonly Dictionary<string, object> output = new Dictionary<string, object>();
        readonly Library library = new Library();

        public override Element VisitLibrary(cqlParser.LibraryContext context)
        {
            Annotation a = new Annotation();
            a.type = "CqlToElmInfo";
            a.translatorOption = "EnableAnnotations,EnableLocators,EnableResultTypes";
            List<Annotation> annotation = new List<Annotation>
            {
                a
            };

            library.annotations = annotation;

            // Parse library identifier
            library.identifier = new VersionedIdentifier
            {
                id = context.libraryDefinition().qualifiedIdentifier().GetText(),
                version = context.libraryDefinition().versionSpecifier()?.GetText() ?? "1.0.0"
            };

            // Parse schema identifier
            library.schemaIdentifier = new VersionedIdentifier
            {
                id = "urn:hl7-org:elm",
                version = "r1"
            };
            UsingsCollection usingsCollection = new UsingsCollection();
            List<UsingDef> def = new List<UsingDef>();
            UsingDef usingSytemDef = new UsingDef
            {
                localId = "System",
                uri = "urn:hl7-org:elm-types:r1"
            };
            def.Add(usingSytemDef);
            //Parse usings
            foreach (var usingContext in context.definition().Where(x=>x.usingDefinition()!=null).Select(x=>x.usingDefinition()))
            {
                if (usingContext != null)
                {
                    var usingDef = VisitUsingDefinition(usingContext);
                    def.Add((UsingDef)usingDef);
                }


            }
            
            usingsCollection.def = def;
            library.usings = usingsCollection;

            // Parse includes
            IncludeCollection includeCollection = new IncludeCollection();
            List<IncludeDef> includedef = new List<IncludeDef>();
            foreach (var includeContext in context.definition().Where(X=>X.includeDefinition()!=null).Select(x=>x.includeDefinition()))
            {
                var includeDef = VisitIncludeDefinition(includeContext);
                includedef.Add((IncludeDef)includeDef);
            }

            includeCollection.def = includedef;
            library.includes = includeCollection;
            //// Parse codesystems
            //foreach (var codesystemContext in context.codesystemDefinition())
            //{
            //    var codesystemDef = VisitCodesystemDefinition(codesystemContext);
            //    library.Codesystems.Add(codesystemDef);
            //}

            //// Parse valuesets
            //foreach (var valuesetContext in context.valuesetDefinition())
            //{
            //    var valuesetDef = VisitValuesetDefinition(valuesetContext);
            //    library.ValueSets.Add(valuesetDef);
            //}

            //// Parse parameters
            //foreach (var parameterContext in context.parameterDefinition())
            //{
            //    var parameterDef = VisitParameterDefinition(parameterContext);
            //    library.Parameters.Add(parameterDef);
            //}

            return library;
        }
        public override Element VisitUsingDefinition([NotNull] cqlParser.UsingDefinitionContext context)
        {
          
            var usingInfo = new UsingDef
            {
                localId = context.modelIdentifier()?.GetText().ToLower() ?? "",
                locator = context.Start.Line.ToString()+":"+ context.Start.Column.ToString()+"-"+context.Stop.Line.ToString() + ":" + context.Stop.Column.ToString(),
                localIdentifier = context.modelIdentifier()?.GetText() ?? "",
                uri = "http://hl7.org/fhir",
                version = context.versionSpecifier()?.GetText() ?? ""
            };
           

            return usingInfo;
        }

        public override Element VisitIncludeDefinition([NotNull] cqlParser.IncludeDefinitionContext context)
        {
            var includeInfo = new IncludeDef
            {
                localId = context.Start.Line.ToString(), // Use the line number as localId
                locator = $"{context.Start.Line}:{context.Start.Column}-{context.Stop.Line}:{context.Stop.Column}",
                localIdentifier = context.localIdentifier()?.GetText() ?? "",
                path = context.qualifiedIdentifier()?.GetText(), // Get the path based on the localIdentifier
                version = context.versionSpecifier()?.GetText() ?? ""
            };


            return includeInfo;
            //var alias = context.qualifiedIdentifier().GetText();
            //var path = context.versionSpecifier().GetText();
            //var key = context.localIdentifier().GetText().ToLower();

        }

        public override Element VisitCodesystemDefinition([NotNull] cqlParser.CodesystemDefinitionContext context)
        {
            var key = "codeSystems";

            if (!output.ContainsKey(key))
            {
                output[key] = new Dictionary<string, object>();
            }

            var codeSystems = (Dictionary<string, object>)output[key];
            if (!codeSystems.ContainsKey("def"))
            {
                codeSystems["def"] = new List<object>();
            }

            ((List<object>)codeSystems["def"]).Add(new Dictionary<string, string>
            {
            { "name", context.accessModifier().GetText() },
            { "id", context.identifier().GetText() },
            { "accessLevel", "Public" }
            });

            return base.VisitCodesystemDefinition(context);
        }

        public override Element VisitValuesetDefinition([NotNull] cqlParser.ValuesetDefinitionContext context)
        {
            var key = "valueSets";

            if (!output.ContainsKey(key))
            {
                output[key] = new Dictionary<string, object>();
            }

            var valueSets = (Dictionary<string, object>)output[key];
            if (!valueSets.ContainsKey("def"))
            {
                valueSets["def"] = new List<object>();
            }

            ((List<object>)valueSets["def"]).Add(new Dictionary<string, string>
            {
            { "name", context.identifier().GetText() },
            { "id", context.valuesetId().GetText() },
            { "accessLevel", "Public" }
            });

            return base.VisitValuesetDefinition(context);
        }

        public override Element VisitParameterDefinition([NotNull] cqlParser.ParameterDefinitionContext context)
        {
            var key = "parameters";

            if (!output.ContainsKey(key))
            {
                output[key] = new Dictionary<string, object>();
            }

            var parameters = (Dictionary<string, object>)output[key];
            if (!parameters.ContainsKey("def"))
            {
                parameters["def"] = new List<object>();
            }

            ((List<object>)parameters["def"]).Add(new Dictionary<string, object>
            {
            { "localId", context.GetText() }, // You can adjust this to get the desired localId format
            { "locator", context.GetText() }, // You can adjust this to get the desired locator format
            { "name", context.identifier().GetText() },
            { "accessLevel", "Public" },
            { "resultTypeSpecifier", Visit(context.typeSpecifier()) },
            { "parameterTypeSpecifier", Visit(context.typeSpecifier()) } // Adjust as needed
            });

            return base.VisitParameterDefinition(context);
        }

        // Implement the remaining Visit methods for other definition types

        // Override the default behavior for handling nested elements
        //public override Element VisitChildren([NotNull] IRuleNode node)
        //{
        //    foreach (var child in node.Parent)
        //    {
        //        Visit(child);
        //    }
        //    return null;
        //}
        #region ParseTreeVisitorMethods
        
      
      

        public override Element VisitLibraryDefinition([NotNull] cqlParser.LibraryDefinitionContext context)
        {
            Annotation a = new Annotation();
            a.type = "CqlToElmInfo";
            a.translatorOption = "EnableAnnotations,EnableLocators,EnableResultTypes";
            List<Annotation> annotation = new List<Annotation>
            {
                a
            };

            library.annotations = annotation;
            
            // Parse library identifier
            library.identifier = new VersionedIdentifier
            {
                id = context.qualifiedIdentifier().GetText(),
                version = context.versionSpecifier()?.GetText() ?? "1.0.0"
            };

            // Parse schema identifier
            library.schemaIdentifier = new VersionedIdentifier
            {
                id = "urn:hl7-org:elm",
                version = "r1"
            };

            // Parse usings
            //foreach (var usingContext in context.())
            //{
            //    var usingDef = VisitUsingDefinition(usingContext);
            //    library.Usings.Add(usingDef);
            //}

            //// Parse includes
            //foreach (var includeContext in context.())
            //{
            //    var includeDef = VisitIncludeDefinition(includeContext);
            //    library.Includes.Add(includeDef);
            //}

            //// Parse codesystems
            //foreach (var codesystemContext in context.codesystemDefinition())
            //{
            //    var codesystemDef = VisitCodesystemDefinition(codesystemContext);
            //    library.Codesystems.Add(codesystemDef);
            //}

            //// Parse valuesets
            //foreach (var valuesetContext in context.valuesetDefinition())
            //{
            //    var valuesetDef = VisitValuesetDefinition(valuesetContext);
            //    library.ValueSets.Add(valuesetDef);
            //}

            //// Parse parameters
            //foreach (var parameterContext in context.parameterDefinition())
            //{
            //    var parameterDef = VisitParameterDefinition(parameterContext);
            //    library.Parameters.Add(parameterDef);
            //}

            return library;
        }
        #endregion

        #region CQLHelperMethods

        private string GetClassName(string existenceModifier, string topic, string modality)
        {
            return String.Format("{0}{1}{2}", topic, modality ?? String.Empty, existenceModifier);
        }

        #endregion

        #region CQLGrammarMethods

       
        public override Element VisitRetrieve(cqlParser.RetrieveContext context)
        {
            //var occurrence = context.occurrence();
            //var topic = context.topic();
            //var modality = context.modality();
            //var className =
            //    GetClassName
            //    (
            //        occurrence == null
            //            ? "Occurrence"
            //            : (occurrence.GetText() == "no" ? "NonOccurrence" : "UnknownOccurrence"),
            //        topic.GetText(),
            //        modality == null ? null : modality.GetText()
            //    );

            //var valueset = context.valueset();
            //var valuesetPathIdentifier = context.valuesetPathIdentifier();
            //var during = context.expression();
            //var duringPathIdentifier = context.duringPathIdentifier();

            var request = new ClinicalRequest();

            request.cardinality = RequestCardinality.Multiple;
            //request.dataType = className; // TODO: xml qualifier for data model?
            //if (valueset != null)
            //{
            //    request.codes = (Expression)Visit(valueset);
            //    if (valuesetPathIdentifier != null)
            //    {
            //        request.codeProperty = valuesetPathIdentifier.GetText();
            //    }
            //}

            //if (during != null)
            //{
            //    request.dateRange = (Expression)Visit(during);
            //    if (duringPathIdentifier != null)
            //    {
            //        request.dateProperty = duringPathIdentifier.GetText();
            //    }
            //}

            return request;
        }

        public override Element VisitQualifiedIdentifier(cqlParser.QualifiedIdentifierContext context)
        {
            var qualifier = context.qualifier();
            var identifier = context.identifier().GetText();

            return new ExpressionRef { libraryName = qualifier == null ? null : qualifier.ToString(), name = identifier };
        }

        public override Element VisitQuerySource(cqlParser.QuerySourceContext context)
        {
            var retrieve = context.retrieve();
            if (retrieve != null)
            {
                return VisitRetrieve(retrieve);
            }

            var qualifiedIdentifier = context.qualifiedIdentifierExpression();
            if (qualifiedIdentifier != null)
            {
                return VisitQualifiedIdentifierExpression(qualifiedIdentifier);
            }

            var expression = context.expression();
            if (expression != null)
            {
                return Visit(expression);
            }

            throw new NotSupportedException("Unknown query source category.");
        }

        public override Element VisitQuery(cqlParser.QueryContext context)
        {
            var aliasedSource = context.sourceClause();
           var querySource = (Expression)Visit(aliasedSource.aliasedQuerySource(0).querySource());
            var alias = aliasedSource.aliasedQuerySource(0).alias().GetText();
           var result = (Expression)new Filter { source = querySource, scope = alias };
            var condition = new And { operand = new List<Expression>() };

            //foreach (var queryInclusionClause in context.queryInclusionClause())
            //{
            //    // NOTE: This only works with "with" clauses right now. If we add "combine" it will need to be dealt with here.
            //    var withSource = (Expression)VisitQuerySource(queryInclusionClause.aliasedQuerySource().querySource());
            //    var withAlias = queryInclusionClause.aliasedQuerySource().alias().GetText();
            //    var withCondition = (Expression)Visit(queryInclusionClause.expression());
            //    var withExpression = new IsNotEmpty { operand = new Filter { source = withSource, scope = withAlias, condition = withCondition } };
            //    condition.operand.Add(withExpression);
            //}

            var whereClause = context.whereClause();
            if (whereClause != null)
            {
                condition.operand.Add((Expression)Visit(whereClause.expression()));
            }

            var returnClause = context.returnClause();
            if (returnClause != null)
            {
                result = new ForEach { source = result, scope = alias, element = (Expression)Visit(returnClause.expression()) };
            }

            var sortClause = context.sortClause();
            if (sortClause != null)
            {
                var sortDirection = sortClause.sortDirection();
                if (sortDirection != null)
                {
                    if (sortDirection.GetText() != "asc")
                    {
                        // TODO: CQL-LM must be modified to support directional sort
                        throw new NotSupportedException();
                    }

                    result = new Sort { source = result };
                }
                else
                {
                    if (sortClause.sortByItem().Count() != 1)
                    {
                        // TODO: CQL-LM must be modified to support multi-column sort
                        throw new NotSupportedException();
                    }

                    if (sortClause.sortByItem(0).sortDirection() != null && sortClause.sortByItem(0).sortDirection().GetText() != "asc")
                    {
                        // TODO: CQL-LM must be modified to support directional sort
                        throw new NotSupportedException();
                    }

                    return new Sort { source = result, orderBy = sortClause.sortByItem(0).expressionTerm().GetText() };
                }
            }

            return result;
        }

        public override Element VisitAdditionExpressionTerm(cqlParser.AdditionExpressionTermContext context)
        {
            return new Add { operand = new List<Expression> { (Expression)Visit(context.expressionTerm(0)), (Expression)Visit(context.expressionTerm(1)) } };
        }

        public override Element VisitAggregateExpressionTerm(cqlParser.AggregateExpressionTermContext context)
        {
            switch (context.GetChild(0).GetText())
            {
                case "distinct":
                    return new Distinct { source = (Expression)Visit(context.expression()) };
                    break;

                case "collapse":
                    return new Collapse { operand = (Expression)Visit(context.expression()) };
                    break;

                case "expand":
                    return new Expand { operand = (Expression)Visit(context.expression()) };
                    break;
            }

            throw new NotSupportedException(String.Format("Unrecognized operator for aggregateExpressionTerm: {0}", context.GetChild(0).GetText()));
        }

        public override Element VisitDefinition(cqlParser.DefinitionContext context)
        {
            var library = new Library();

            

          

            //foreach (var parameterDefinition in context.parameterDefinition())
            //{
            //    library.parameters.Add(new ParameterDef { name = parameterDefinition.identifier().GetText(), parameterType = new XmlQualifiedName(parameterDefinition.typeSpecifier().GetText()) });
            //}


            string currentContext = Contexts.PATIENT;
            //foreach (var statement in context.statement())
            //{
            //    var contextDefinition = statement.contextDefinition();
            //    if (contextDefinition != null)
            //    {
            //        var newContext = contextDefinition.identifier().GetText();
            //        if (newContext == Contexts.PATIENT || newContext == Contexts.POPULATION)
            //        {
            //            currentContext = newContext;
            //        }
            //        else
            //        {
            //            throw new InvalidOperationException(String.Format("Unknown context {0}.", newContext));
            //        }
            //    }

            //    var letStatement = statement.expressionDefinition();
            //    if (letStatement != null)
            //    {
            //        library.statements.Add(new ExpressionDef { name = letStatement.identifier().GetText(), context = currentContext, expression = (Expression)Visit(letStatement.expression()) });
            //    }

            //    var functionDefinition = statement.functionDefinition();
            //    if (functionDefinition != null)
            //    {
            //        var functionDef = new FunctionDef { name = functionDefinition.identifierOrFunctionIdentifier().GetText(), context = currentContext, expression = (Expression)Visit(functionDefinition.functionBody()) };
            //        foreach (var parameter in functionDefinition.operandDefinition())
            //        {
            //            // TODO: More complete type resolution here, although ELM will have to be expanded to support this as well....
            //            functionDef.parameter.Add(new ParameterDef { name = parameter.referentialIdentifier().GetText(), parameterType = new XmlQualifiedName(parameter.typeSpecifier().GetText()) });
            //        }

            //        library.statements.Add(functionDef);
            //    }

               
            //}

            return library;
        }

        #endregion
    }
}
