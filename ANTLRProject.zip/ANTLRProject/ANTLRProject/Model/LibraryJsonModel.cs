﻿
using ANTLRProject.Model.ResponseModel;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model
{
    [DataContract]
    public class LibraryJsonModel :IElementResponseModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("library")]
        public LibraryResponseModel Library { get; set; }
    }
}
