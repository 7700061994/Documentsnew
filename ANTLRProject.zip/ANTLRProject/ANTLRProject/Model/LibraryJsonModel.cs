﻿
using ANTLRProject.Model.ElmModel;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model
{
    [DataContract]
    public class LibraryJsonModel :IElementModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("library")]
        public LibraryModel Library { get; set; }
    }
}
