﻿using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class AnnotationModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("translatorOption")]
        public string TranslatorOption { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("type")]
        public string Type { get; set; }
    }
}
