﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class LibraryModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("annotation")]
        public List<AnnotationModel> Annotation { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("identifier")]
        public VersionedIdentifierModel Identifier { get; set; }
        [DataMember(Order = 3)]
        [JsonProperty("schemaIdentifier")]
        public VersionedIdentifierModel SchemaIdentifier { get; set; }
        [DataMember(Order = 4)]
        [JsonProperty("usings")]
        public UsingsCollectionModel Usings { get; set; }
        [DataMember(Order = 5)]
        [JsonProperty("includes")]
        public IncludeCollectionModel Includes { get; set; }
    }
}
