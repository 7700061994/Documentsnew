﻿using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class VersionedIdentifierModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("id")]
        public string Id { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("version")]
        public string Version { get; set; }
    }
}
