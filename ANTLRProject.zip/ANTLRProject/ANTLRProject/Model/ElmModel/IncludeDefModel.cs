﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class IncludeDefModel:IElementModel
    {

        [DataMember(Order = 1)]
        [JsonProperty("localId")]
        public string LocalId { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("locator")]
        public string Locator { get; set; }
        [DataMember(Order = 3)]
        [JsonProperty("localIdentifier")]
        public string LocalIdentifier { get; set; }
        [DataMember(Order = 4)]
        [JsonProperty("path")]
        public string Path { get; set; }
        [DataMember(Order = 5)]
        [JsonProperty("version")]
        public string Version { get; set; }
    }
}
