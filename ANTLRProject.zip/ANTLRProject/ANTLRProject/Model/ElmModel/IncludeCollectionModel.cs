﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class IncludeCollectionModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("def")]
        public List<IncludeDefModel> Definations { get; set; }
    }
}
