﻿using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ElmModel
{
    [DataContract]
    public class UsingDefResponseModel : IElementModel
    {
        
        [DataMember(EmitDefaultValue = false,Order = 1)]
        [JsonProperty("localId", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public string LocalId { get; set; }
        [DataMember(EmitDefaultValue = false,Order = 2)]
        [JsonProperty("locator", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public string Locator { get; set; }
        [DataMember(Order = 3, EmitDefaultValue = false)]
        [JsonProperty("localIdentifier")]
        public string LocalIdentifier { get; set; }
        [DataMember(Order = 4, EmitDefaultValue = false)]
        [JsonProperty("uri")]
        public string Uri { get; set; }
        [DataMember(EmitDefaultValue = false,Order = 5)]
        [JsonProperty("version", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public string Version { get; set; }
    }
}
