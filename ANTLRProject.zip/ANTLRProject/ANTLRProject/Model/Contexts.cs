﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject.Model
{
	public static class Contexts
	{
		public const string PATIENT = "PATIENT";
		public const string POPULATION = "POPULATION";
	}
}
