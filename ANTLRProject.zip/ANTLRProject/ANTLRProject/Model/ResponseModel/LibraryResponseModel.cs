﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject.Model.ResponseModel
{
    [DataContract]
    public class LibraryResponseModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("annotation")]
        public List<AnnotationResponseModel> Annotation { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("identifier")]
        public VersionedIdentifierResponseModel Identifier { get; set; }
        [DataMember(Order = 3)]
        [JsonProperty("schemaIdentifier")]
        public VersionedIdentifierResponseModel SchemaIdentifier { get; set; }
        [DataMember(Order = 4)]
        [JsonProperty("usings")]
        public UsingsCollectionResponseModel Usings { get; set; }
        [DataMember(Order = 5)]
        [JsonProperty("includes")]
        public IncludeCollectionResponseModel Includes { get; set; }
    }
}
