﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ANTLRProject.Model.ResponseModel
{
    [DataContract]
    public class UsingsCollectionResponseModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("def")]
        public List<UsingDefResponseModel> Definations { get; set; }
    }
}
