﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ResponseModel
{
    [DataContract]
    public class IncludeCollectionResponseModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("def")]
        public List<IncludeDefResponseModel> Definations { get; set; }
    }
}
