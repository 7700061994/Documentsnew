﻿using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace ANTLRProject.Model.ResponseModel
{
    [DataContract]
    public class AnnotationResponseModel
    {
        [DataMember(Order = 1)]
        [JsonProperty("translatorOption")]
        public string TranslatorOption { get; set; }
        [DataMember(Order = 2)]
        [JsonProperty("type")]
        public string Type { get; set; }
    }
}
