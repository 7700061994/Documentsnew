CQL:  v1.4
CQL Execution Engine:  v2.2.0
CQL Exec FHIR:  v1.5.0
FHIR:  v4.0.1

For more information on NCQA's digital quality measures, please see the HEDIS Implementation Guide in the documents folder.